--08/05/2022
--Vers�o 1.0
--Database do Projeto2 SD
	--Cria��o da Base de dados
USE master
GO

DROP DATABASE IF EXISTS SD_Database
CREATE DATABASE SD_Database
GO

USE SD_Database
GO

--Tabelas--

CREATE TABLE Utilizadores(
	Id					INTEGER			NOT NULL,
	Nome				VARCHAR(100)	NOT NULL,
	Pass				VARCHAR(50)		NOT NULL,
	Isadm				BIT				NOT NULL DEFAULT 0,
	--difern�a admin e operador, 1-admin 0-operador
	PRIMARY KEY (Id)
)

CREATE TABLE Domicilios(
	NumeroAdministrativo	INTEGER			NOT NULL,
	Municipio				VARCHAR(100)	NOT NULL,
	Morada					VARCHAR(100)	NOT NULL,
	Operador				VARCHAR(50)		NOT NULL,
	Estado					INTEGER			NOT NULL DEFAULT 0,	
	Modalidade				VARCHAR(10)			NOT NULL,

	PRIMARY KEY (Numeroadministrativo),
	--estado, 0-livre 1-reservado 2-ativado 3-desativado 4-terminado
)
