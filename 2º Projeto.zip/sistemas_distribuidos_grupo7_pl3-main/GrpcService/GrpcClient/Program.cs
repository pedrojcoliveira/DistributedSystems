﻿using Grpc.Core;
using RabbitMQ.Client.Events;
using GrpcServer;
using System;
using System.Text;
using System.Threading.Tasks;
using Grpc.Net.Client;
using RabbitMQ.Client;
using GrpcServer.Protos;
using System.Runtime.CompilerServices;
using System.Net;

namespace GrpcClient
{
    class Program
    {
        static async Task Main(string[] args)
        {
            //var ipAddress = IPAddress.Parse("127.0.0.1"); //Mudar para testes

            var grpcChannel = GrpcChannel.ForAddress("https://localhost:7237");

            // Configuração RabbitMQ
            var factory = new ConnectionFactory { HostName = "localhost" };

            using var connection = factory.CreateConnection();
            using var channel = connection.CreateModel();

            channel.ExchangeDeclare(exchange: "direct_logs", type: ExchangeType.Direct);
            var queueName = channel.QueueDeclare().QueueName;
            channel.QueueBind(queue: queueName, exchange: "direct_logs", routingKey: "severity");

            var consumer = new EventingBasicConsumer(channel);
            consumer.Received += (model, args) =>
            {
                var messageBytes = args.Body.ToArray();
                var notificationMessage = Encoding.UTF8.GetString(messageBytes);
                Console.WriteLine($"Received notification: {notificationMessage}");
            };

            channel.BasicConsume(queue: queueName, autoAck: true, consumer: consumer);


            Console.WriteLine("Insira o seu UserName: ");
            string username = Console.ReadLine();
            Console.WriteLine("Insira a sua Password: ");
            string password = "";

            while (true)
            {
                ConsoleKeyInfo key = Console.ReadKey(true);

                // Verificar se a tecla pressionada é Enter para finalizar a entrada da senha
                if (key.Key == ConsoleKey.Enter)
                {
                    break;
                }
                // Verificar se a tecla pressionada é Backspace para remover o último caractere digitado
                else if (key.Key == ConsoleKey.Backspace)
                {
                    if (password.Length > 0)
                    {
                        password = password.Substring(0, password.Length - 1);
                        Console.Write("\b \b"); // Apaga o último asterisco exibido
                    }
                }
                // Verificar se o caractere digitado é um caractere imprimível
                else if (char.IsLetterOrDigit(key.KeyChar) || char.IsPunctuation(key.KeyChar) || char.IsSymbol(key.KeyChar))
                {
                    password += key.KeyChar;
                    Console.Write("*"); // Exibe um asterisco no lugar do caractere digitado
                }
            }

            var client = new Customer.CustomerClient(grpcChannel);
            var resposta = await client.LoginAsync(new CustomerRequest { Nome = username, Pass=password});

            if (resposta.Isadm == true)
            {
                //Admin
                Console.WriteLine("\nLogado como Cliente (Administrador)");           

                
                    var continuar = true;
                    while (continuar == true)
                    {
                    //Admin
                    Console.WriteLine("O que deseja fazer [1]Listar servicos, [2]Alterar servicos");
                    var opcao= Console.ReadLine();
                    if (opcao == "1")
                    {
                        Console.WriteLine("O que deseja listar [1]Reservados, [2]Ativados, [3]Desativados, [4]Terminados, [5]Sair");
                        string processos = Console.ReadLine();

                        if (processos == "1")
                        {
                            var reservationClient = new Reservation.ReservationClient(grpcChannel);


                            var request = new ReservationLookupModel
                            {
                                Estado = 1
                            };

                            try
                            {

                                var response = reservationClient.VerReservar(request);

                                // Processar a resposta do servidor
                                // Por task sleep para simular
                                foreach (var domicilio in response.Domicilios)
                                {
                                    Console.WriteLine($"Número Administrativo: {domicilio.NumeroAdministrativo}");
                                    Console.WriteLine($"Município: {domicilio.Municipio}");
                                    Console.WriteLine($"Morada: {domicilio.Morada}");
                                    Console.WriteLine($"Operador: {domicilio.Operador}");
                                    Console.WriteLine($"Modalidade: {domicilio.Modalidade}");
                                    Console.WriteLine();
                                }
                            }
                            catch (RpcException ex)
                            {
                                Console.WriteLine($"Erro ao listar domicilios reservados: {ex.Message}");
                            }
                        }
                        else if (processos == "2")
                        {
                            var activationClient = new Activation.ActivationClient(grpcChannel);

                            // Criação da mensagem ActivationLookupModel
                            var request = new ActivationLookupModel
                            {
                                Estado = 2
                            };

                            try
                            {
                                // Chamada do método VerAtivar no servidor
                                var response = activationClient.VerAtivar(request);

                                // Processar a resposta do servidor
                                // Por task sleep para simular
                                foreach (var domicilio in response.Domicilios)
                                {
                                    Console.WriteLine($"Número Administrativo: {domicilio.NumeroAdministrativo}");
                                    Console.WriteLine($"Município: {domicilio.Municipio}");
                                    Console.WriteLine($"Morada: {domicilio.Morada}");
                                    Console.WriteLine($"Operador: {domicilio.Operador}");
                                    Console.WriteLine($"Modalidade: {domicilio.Modalidade}");
                                    Console.WriteLine();
                                }
                            }
                            catch (RpcException ex)
                            {
                                Console.WriteLine($"Erro ao listar domicilios ativados: {ex.Message}");
                            }
                        }
                        else if (processos == "3")
                        {
                            var desactivationClient = new Desactivation.DesactivationClient(grpcChannel);


                            var request = new DesactivationLookupModel
                            {
                                Estado = 3
                            };

                            try
                            {

                                var response = desactivationClient.VerDesativar(request);

                                // Processar a resposta do servidor
                                // Por task sleep para simular
                                foreach (var domicilio in response.Domicilios)
                                {
                                    Console.WriteLine($"Número Administrativo: {domicilio.NumeroAdministrativo}");
                                    Console.WriteLine($"Município: {domicilio.Municipio}");
                                    Console.WriteLine($"Morada: {domicilio.Morada}");
                                    Console.WriteLine($"Operador: {domicilio.Operador}");
                                    Console.WriteLine($"Modalidade: {domicilio.Modalidade}");
                                    Console.WriteLine();
                                }
                            }
                            catch (RpcException ex)
                            {
                                Console.WriteLine($"Erro ao listar domicilios desativados: {ex.Message}");
                            }
                        }
                        else if (processos == "4")
                        {
                            var terminationClient = new Termination.TerminationClient(grpcChannel);


                            var request = new TerminationLookupModel
                            {
                                Estado = 4
                            };

                            try
                            {

                                var response = terminationClient.VerTerminar(request);

                                // Processar a resposta do servidor
                                // Por task sleep para simular
                                foreach (var domicilio in response.Domicilios)
                                {
                                    Console.WriteLine($"Número Administrativo: {domicilio.NumeroAdministrativo}");
                                    Console.WriteLine($"Município: {domicilio.Municipio}");
                                    Console.WriteLine($"Morada: {domicilio.Morada}");
                                    Console.WriteLine($"Operador: {domicilio.Operador}");
                                    Console.WriteLine($"Modalidade: {domicilio.Modalidade}");
                                    Console.WriteLine();
                                }
                            }
                            catch (RpcException ex)
                            {
                                Console.WriteLine($"Erro ao listar domicilios terminados: {ex.Message}");
                            }
                        }
                        else if (processos == "5")
                        {
                            continuar = false;
                        }
                        else
                        {
                            Console.WriteLine("Opção inválida");
                        }
                    }
                    if (opcao == "2")
                    {
                        Console.WriteLine("O que deseja fazer [1]Reserva, [2]Ativacao, [3]Desativacao, [4]Terminacao, [5]Sair");
                        string oquefazer = Console.ReadLine();
                        if (oquefazer == "1")
                        {
                            var reservationClient = new Reservation.ReservationClient(grpcChannel);

                            Console.WriteLine("Indique o municipio:");
                            string municipio = Console.ReadLine();

                            Console.WriteLine("Indique a modalidade:");
                            string modalidade = Console.ReadLine();

                            var response = reservationClient.Reserva(new ReservationRequest { Municipio = municipio, Modalidade = modalidade });

                            if (response.Sucesso)
                            {
                                Console.WriteLine($"Número Administrativo: {response.NumeroAdministrativo}");
                                Console.WriteLine("Reserva efetuada");
                            }
                            else
                            {
                                Console.WriteLine("Municipio não encontrado ou não é possível reserva.");
                            }
                        }
                        else if (oquefazer == "2")
                        {
                            var activationClient = new Activation.ActivationClient(grpcChannel);

                            Console.WriteLine("Indique o numero administrativo para efetuar a ativacao:");
                            int numadmin = int.Parse(Console.ReadLine());

                            var response = await activationClient.AtivarAsync(new ActivationRequest { NumeroAdministrativo = numadmin });

                            if (response.Sucesso)
                            {
                                Console.WriteLine($"Tempo de espera para finalizar ativacao: {response.TempoEstimado}");

                            }
                            else
                            {
                                Console.WriteLine("Municipio não encontrado ou não é possível desativar.");
                            }
                        }
                        else if (oquefazer == "3")
                        {
                            var desactivationClient = new Desactivation.DesactivationClient(grpcChannel);

                            Console.WriteLine("Indique o numero administrativo para efetuar a desativacao:");
                            int numadmin = int.Parse(Console.ReadLine());

                            var response = await desactivationClient.DesativarAsync(new DesactivationRequest { NumeroAdministrativo = numadmin });

                            if (response.Sucesso)
                            {
                                Console.WriteLine($"Tempo de espera para finalizar desativacao: {response.TempoEstimado}");

                            }
                            else
                            {
                                Console.WriteLine("Municipio não encontrado ou não é possível desativar.");
                            }
                        }
                        else if (oquefazer == "4")
                        {
                            var terminationClient = new Termination.TerminationClient(grpcChannel);

                            Console.WriteLine("Indique o numero admistrativo para efetuar a terminacao:");
                            int numadmin = int.Parse(Console.ReadLine());

                            var response = await terminationClient.TerminarAsync(new TerminationRequest { NumeroAdministrativo = numadmin });

                            if (response.Sucesso)
                            {
                                Console.WriteLine($"Número Administrativo: {response.TempoEstimado}");
                                Console.WriteLine("Terminacao efetuada");
                            }
                            else
                            {
                                Console.WriteLine("Municipio não encontrado ou não é possível terminar.");
                            }
                        }
                        else if (oquefazer == "5")
                        {
                            continuar = false;
                        }
                        else
                        {
                            Console.WriteLine("Opção inválida");
                        }
                    
                    }
                    }
            }
            else
            {
                //Operador externo
                Console.WriteLine("\nLogado como Cliente (Operador externo)");
                
                var continuar = true;

                while (continuar == true)
                {
                    Console.WriteLine("O que deseja fazer [1]Reserva, [2]Ativacao, [3]Desativacao, [4]Terminacao, [5]Sair");
                    string oquefazer = Console.ReadLine();
                    if (oquefazer == "1")
                    {
                        var reservationClient = new Reservation.ReservationClient(grpcChannel);

                        Console.WriteLine("Indique o municipio:");
                        string municipio = Console.ReadLine();

                        Console.WriteLine("Indique a modalidade:");
                        string modalidade = Console.ReadLine();

                        var response = reservationClient.Reserva(new ReservationRequest { Municipio = municipio, Modalidade = modalidade });

                        if (response.Sucesso)
                        {
                            Console.WriteLine($"Número Administrativo: {response.NumeroAdministrativo}");
                            Console.WriteLine("Reserva efetuada");
                        }
                        else
                        {
                            Console.WriteLine("Municipio não encontrado ou não é possível reserva.");
                        }
                    }
                    else if (oquefazer == "2")
                    {
                        var activationClient = new Activation.ActivationClient(grpcChannel);

                        Console.WriteLine("Indique o numero administrativo para efetuar a ativacao:");
                        int numadmin = int.Parse(Console.ReadLine());

                        var response = await activationClient.AtivarAsync(new ActivationRequest { NumeroAdministrativo = numadmin });

                        if (response.Sucesso)
                        {
                            Console.WriteLine($"Tempo de espera para finalizar ativacao: {response.TempoEstimado}");

                        }
                        else
                        {
                            Console.WriteLine("Municipio não encontrado ou não é possível desativar.");
                        }
                    }
                    else if (oquefazer == "3")
                    {
                        var desactivationClient = new Desactivation.DesactivationClient(grpcChannel);

                        Console.WriteLine("Indique o numero administrativo para efetuar a desativacao:");
                        int numadmin = int.Parse(Console.ReadLine());

                        var response = await desactivationClient.DesativarAsync(new DesactivationRequest { NumeroAdministrativo = numadmin });

                        if (response.Sucesso)
                        {
                            Console.WriteLine($"Tempo de espera para finalizar desativacao: {response.TempoEstimado}");

                        }
                        else
                        {
                            Console.WriteLine("Municipio não encontrado ou não é possível desativar.");
                        }
                    }
                    else if (oquefazer == "4")
                    {
                        var terminationClient = new Termination.TerminationClient(grpcChannel);

                        Console.WriteLine("Indique o numero admistrativo para efetuar a terminacao:");
                        int numadmin = int.Parse(Console.ReadLine());

                        var response = await terminationClient.TerminarAsync(new TerminationRequest { NumeroAdministrativo = numadmin });

                        if (response.Sucesso)
                        {
                            Console.WriteLine($"Número Administrativo: {response.TempoEstimado}");
                            Console.WriteLine("Terminacao efetuada");
                        }
                        else
                        {
                            Console.WriteLine("Municipio não encontrado ou não é possível terminar.");
                        }
                    }
                    else if (oquefazer == "5")
                    {
                        continuar = false;
                    }
                    else
                    {
                        Console.WriteLine("Opção inválida");
                    }
                }
            }
            Console.WriteLine("Pressione enter para sair.");
            Console.ReadLine();
        }
    }
}

