﻿using GrpcServer.Classes;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace GrpcServer
{
   
    public class ContextoBD : DbContext
    {
        public DbSet<ClasseUtilizador> Utilizadores { get; set; }
        public DbSet<ClasseDomicilio> Domicilios { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=SD_Database;Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=SD_Database;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}
