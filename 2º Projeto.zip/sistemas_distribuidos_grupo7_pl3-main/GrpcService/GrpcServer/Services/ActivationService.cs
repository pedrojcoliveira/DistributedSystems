﻿using Grpc.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GrpcServer.Protos;
using RabbitMQ.Client;
using System.Text;
using Azure;

namespace GrpcServer.Services
{
    public class ActivationService : Activation.ActivationBase
    {
        public async override Task<ActivationResponse> Ativar(ActivationRequest request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Catch do número administrativo
                var numadmin = contexto.Domicilios.FirstOrDefault(m => m.NumeroAdministrativo == request.NumeroAdministrativo);

                if (numadmin != null)
                {
                    if (numadmin.Estado == 1 || numadmin.Estado == 3) // 1 equivale a estado reservado e 3 a desativado
                    {
                        // Update do estado
                        numadmin.Estado = 2;
                        contexto.SaveChanges(); // Guarda alterações

                        // Configuração RabbitMQ
                        var factory = new ConnectionFactory { HostName = "localhost" };

                        using var connection = factory.CreateConnection();
                        using var channel = connection.CreateModel();

                        channel.ExchangeDeclare(exchange: "direct_logs", type: ExchangeType.Direct);
                        var message = "Linha de fibra ativada com sucesso!";
                        var messageBytes = Encoding.UTF8.GetBytes(message);
                        channel.BasicPublish(exchange: "direct_logs", routingKey: "severity", basicProperties: null, body: messageBytes);

                        //Arranjar maneira de simular sleep antes do linha de fibra ativada com sucesso
                        // Retorna o tempo estimado
                        return await Task.FromResult(new ActivationResponse { Sucesso = true, TempoEstimado = "5 segundos" });


                    }
                    else
                    {
                        // Não pode ser ativado
                        return await Task.FromResult(new ActivationResponse { Sucesso = false });
                    }
                }
                else
                {
                    // Município não encontrado
                    return await Task.FromResult(new ActivationResponse { Sucesso = false });
                }
            }
        }

        public override Task<ActivationModel> VerAtivar(ActivationLookupModel request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Buscar os domicílios com o estado igual a request.Estado no banco de dados
                var domicilios = contexto.Domicilios.Where(d => d.Estado == request.Estado).ToList();

                var response = new ActivationModel();

                // Mapear os domicílios para a resposta ActivationModel
                foreach (var domicilio in domicilios)
                {
                    response.Domicilios.Add(new ActivationModel.Types.Domicilio
                    {
                        NumeroAdministrativo = domicilio.NumeroAdministrativo,
                        Municipio = domicilio.Municipio,
                        Morada = domicilio.Morada,
                        Operador = domicilio.Operador,
                        Modalidade = domicilio.Modalidade
                    });
                }
                 return Task.FromResult(response);
            }
        }
    }
}

