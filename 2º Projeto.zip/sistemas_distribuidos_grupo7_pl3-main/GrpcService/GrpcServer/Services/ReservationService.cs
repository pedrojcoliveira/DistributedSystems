﻿using Grpc.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GrpcServer.Protos;

namespace GrpcServer.Services
{
    public class ReservationService : Reservation.ReservationBase
    {

        public override Task<ReservationResponse> Reserva(ReservationRequest request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Buscar o número administrativo do município indicado
                var municipio = contexto.Domicilios.FirstOrDefault(m => m.Municipio == request.Municipio);
                

                if (municipio != null)
                {
                    if (municipio.Estado == 0)
                    {
                        // Update do estado
                        municipio.Estado = 1;      
                        municipio.Modalidade = request.Modalidade;
                        contexto.SaveChanges(); // Guarda alterações


                        // Retornar o número administrativo do município encontrado
                        return Task.FromResult(new ReservationResponse { Sucesso = true, NumeroAdministrativo = municipio.NumeroAdministrativo});
                    }
                    else
                    {
                        // Não pode ser reservado
                        return Task.FromResult(new ReservationResponse { Sucesso = false });
                    }
                }
                else
                {
                    // Município não encontrado
                    return Task.FromResult(new ReservationResponse { Sucesso = false });
                }
            }
        }
        public override Task<ReservationModel> VerReservar(ReservationLookupModel request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Buscar os domicílios com o estado igual a request.Estado no banco de dados
                var domicilios = contexto.Domicilios.Where(d => d.Estado == request.Estado).ToList();

                var response = new ReservationModel();

                // Mapear os domicílios para a resposta ActivationModel
                foreach (var domicilio in domicilios)
                {
                    response.Domicilios.Add(new ReservationModel.Types.Domicilio
                    {
                        NumeroAdministrativo = domicilio.NumeroAdministrativo,
                        Municipio = domicilio.Municipio,
                        Morada = domicilio.Morada,
                        Operador = domicilio.Operador,
                        Modalidade = domicilio.Modalidade
                    });
                }
                return Task.FromResult(response);
            }
        }
    }
}

