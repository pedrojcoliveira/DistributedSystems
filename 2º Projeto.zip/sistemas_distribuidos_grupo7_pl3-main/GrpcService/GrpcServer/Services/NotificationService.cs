﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

public class NotificationService
{
    private readonly ConnectionFactory _rabbitFactory;
    private readonly CancellationToken _cancellationToken;

    public NotificationService(ConnectionFactory rabbitFactory, CancellationToken cancellationToken)
    {
        _rabbitFactory = rabbitFactory;
        _cancellationToken = cancellationToken;
    }

    public async Task StartListening()
    {
        using var connection = _rabbitFactory.CreateConnection();
        using var channel = connection.CreateModel();

        channel.ExchangeDeclare(exchange: "direct_logs", type: ExchangeType.Direct);
        var queueName = channel.QueueDeclare().QueueName;
        channel.QueueBind(queue: queueName, exchange: "direct_logs", routingKey: "severity");

        var consumer = new EventingBasicConsumer(channel);
        consumer.Received += (model, args) =>
        {
            var messageBytes = args.Body.ToArray();
            var notificationMessage = Encoding.UTF8.GetString(messageBytes);
            Console.WriteLine($"Send notification: {notificationMessage}");     

        };

        channel.BasicConsume(queue: queueName, autoAck: true, consumer: consumer);

        // Wait for cancellation
        await Task.Delay(Timeout.Infinite, _cancellationToken);
    }
}
