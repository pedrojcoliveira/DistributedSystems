﻿using Grpc.Core;
using RabbitMQ.Client;
using System.Text;

namespace GrpcServer.Services
{
    public class CustomersService : Customer.CustomerBase
    {
        public override Task<CustomerResponse> Login(CustomerRequest request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Catch do número administrativo
                var name = contexto.Utilizadores.FirstOrDefault(n => n.Nome == request.Nome);
                //var pass = contexto.Utilizadores.FirstOrDefault(p => p.Pass == request.Pass);

                if (name != null && name.Pass == request.Pass)
                {
                    if (name.Isadm == true)
                    {
                        return Task.FromResult(new CustomerResponse { Isadm = true });
                    }
                    else
                    {
                        // Não pode ser ativado
                        return Task.FromResult(new CustomerResponse { Isadm = false });
                    }
                }
                else
                {
                    // Utilizador não encontrado
                    var status = new Status(StatusCode.NotFound, "Utilizador não Encontrado");
                    throw new RpcException(status);
                }
            }
        }
    }
}

