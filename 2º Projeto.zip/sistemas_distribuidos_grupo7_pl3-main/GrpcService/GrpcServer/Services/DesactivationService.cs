﻿using Grpc.Core;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GrpcServer.Protos;
using RabbitMQ.Client;
using System.Text;

namespace GrpcServer.Services
{
    public class DesactivationService : Desactivation.DesactivationBase
    {
        public async override Task<DesactivationResponse> Desativar(DesactivationRequest request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Catch do número administrativo
                var numadmin = contexto.Domicilios.FirstOrDefault(m => m.NumeroAdministrativo == request.NumeroAdministrativo);

                if (numadmin != null)
                {
                    if (numadmin.Estado == 2) // 2 equivale a estado ativado
                    {
                        // Update do estado
                        numadmin.Estado = 3;
                        contexto.SaveChanges(); // Guarda alterações

                        // Configuração RabbitMQ
                        var factory = new ConnectionFactory { HostName = "localhost" };

                        using var connection = factory.CreateConnection();
                        using var channel = connection.CreateModel();

                        channel.ExchangeDeclare(exchange: "direct_logs", type: ExchangeType.Direct);
                        var message = "Linha de fibra desativada com sucesso!";
                        var messageBytes = Encoding.UTF8.GetBytes(message);
                        channel.BasicPublish(exchange: "direct_logs", routingKey: "severity", basicProperties: null, body: messageBytes);

                        // Retorna o tempo estimado
                        var desactivationResponse = new DesactivationResponse { Sucesso = true, TempoEstimado = "5 segundos" };

                        // Aguarda o tempo estimado
                        await Task.Delay(5000);

                        // Retorna o resultado completo
                        return desactivationResponse;


                    }
                    else
                    {
                        // Não pode ser reservado
                        return await Task.FromResult(new DesactivationResponse { Sucesso = false });
                    }
                }
                else
                {
                    // Município não encontrado
                    return await Task.FromResult(new DesactivationResponse { Sucesso = false });
                }
            }
        }
        public override Task<DesactivationModel> VerDesativar(DesactivationLookupModel request, ServerCallContext context)
        {
            using (var contexto = new ContextoBD())
            {
                // Buscar os domicílios com o estado igual a request.Estado no banco de dados
                var domicilios = contexto.Domicilios.Where(d => d.Estado == request.Estado).ToList();

                var response = new DesactivationModel();

                // Mapear os domicílios para a resposta ActivationModel
                foreach (var domicilio in domicilios)
                {
                    response.Domicilios.Add(new DesactivationModel.Types.Domicilio
                    {
                        NumeroAdministrativo = domicilio.NumeroAdministrativo,
                        Municipio = domicilio.Municipio,
                        Morada = domicilio.Morada,
                        Operador = domicilio.Operador,
                        Modalidade = domicilio.Modalidade
                    });
                }
                return Task.FromResult(response);
            }
        }
    }
}