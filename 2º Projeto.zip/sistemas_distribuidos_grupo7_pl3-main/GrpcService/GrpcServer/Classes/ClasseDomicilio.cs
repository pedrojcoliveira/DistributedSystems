﻿using System.ComponentModel.DataAnnotations;

namespace GrpcServer.Classes
{
    public class ClasseDomicilio
    {
        [Key]
        public int NumeroAdministrativo { get; set; }

        [Required]
        public string Municipio { get; set; }

        [Required]
        public string Morada { get; set; }

        [Required]
        public string Operador { get; set; }

        [Required]
        public int Estado { get; set; }

        [Required]
        public string Modalidade { get; set;}
    }
}
