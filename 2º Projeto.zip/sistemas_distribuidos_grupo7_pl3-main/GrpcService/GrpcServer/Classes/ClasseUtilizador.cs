﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GrpcServer.Classes
{
    public class ClasseUtilizador
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Nome { get; set; }

        [Required]
        public string Pass { get; set; }

        [Required]
        public bool Isadm { get; set; }
    }
}