using GrpcServer;
using GrpcServer.Services;
using Microsoft.AspNetCore.Connections;
using Microsoft.EntityFrameworkCore;
using RabbitMQ.Client;
using System;
using System.Text;
using System.Threading;

var builder = WebApplication.CreateBuilder(args);

// Additional configuration is required to successfully run gRPC on macOS.
// For instructions on how to configure Kestrel and gRPC clients on macOS, visit https://go.microsoft.com/fwlink/?linkid=2099682

// Add services to the container.
builder.Services.AddGrpc();

// Configura��o do RabbitMQ
var rabbitFactory = new ConnectionFactory { HostName = "localhost", };

var app = builder.Build();

// Start a background task to listen for RabbitMQ notifications
var cancellationTokenSource = new CancellationTokenSource();
var notificationService = new NotificationService(rabbitFactory, cancellationTokenSource.Token);
Task.Run(notificationService.StartListening);

// Configure the HTTP request pipeline.
app.MapGrpcService<CustomersService>();
app.MapGrpcService<ReservationService>();
app.MapGrpcService<DesactivationService>();
app.MapGrpcService<ActivationService>();
app.MapGrpcService<TerminationService>();

app.MapGet("/", () => "Communication with gRPC endpoints must be made through a gRPC client. To learn how to create a client, visit: https://go.microsoft.com/fwlink/?linkid=2086909");
//await runTask; // Wait for the application to complete

app.Run();
