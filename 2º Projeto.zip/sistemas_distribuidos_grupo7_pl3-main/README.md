# Sistemas_Distribuídos_grupo7_pl3

2023 Sistemas Distribuídos
Trabalho prático nº2
Sistema de aprovisionamento Wholesaler


Ao criar a base de dados devem ser adicionados posteriormente dados a mesma, no nosso caso fizemos diretamente através das ferramentas de sql presentes no visual studio, de maneira a não perder muito tempo a fazer querys.

Dados adicionados:

Tabela Utilizadores:

1;Pedro;Oliveira;True;
2;Daniel;Filipe;False;

Tabela Domicilios:

123;Amarante;Rua Cool;Vodafone;0;0;
456;Porto;Rua Maior;NOS;1;500-500;
789;Lamego;Rua Prisao;MEO;2;100-100;
1011;Gaia;Rua Top;Vodafone;3;200-200;
